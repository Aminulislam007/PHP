<a href="logout.php">Logout</a>
