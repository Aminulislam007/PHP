
<?php 
  include_once("include/nav.php");
  include_once("include/nav.php");
  include_once("include/nav.php");
?>

<div> 
<?php 
  require_once("include/img.php");
  require_once("include/img.php");
  require("include/img.php");
  require("include/img.php");

  // include_once 'include/img.php';
?>
  This is my First page.
</div>
   

 