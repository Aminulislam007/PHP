<?php 
require("include/nav.php");
?>
<div> 
    this is my second page.

</div>

