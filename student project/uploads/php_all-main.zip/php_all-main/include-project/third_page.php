<?php 
include("include/nav.php");
?>
<div> 
    this is my third page.

    <?php include("include/img.php")?>
</div>