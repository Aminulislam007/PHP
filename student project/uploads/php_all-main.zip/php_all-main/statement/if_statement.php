<?php 
$a=23;
$A=25;

if($a>20){ 
    echo "Print this value";
} else{ 
    echo "not print";
}
?>