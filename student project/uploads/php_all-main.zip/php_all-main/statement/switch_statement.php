<?php 

 $r = "A";
switch($r) {
 case "A":
 echo "V";
 break;
 case "E":
    echo "V";
 break;
 case "I":
    echo "V";
 break;
 case "O":
    echo "V";
 break;
 case "U":
    echo "V";
 break;
default:
echo "C";
}
?>