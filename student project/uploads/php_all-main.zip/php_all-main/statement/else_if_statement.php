
<?php 
 $a=23;
 $b=150;
 $c=6;
  if($a>$b){ 
    echo "This is true statement";
  }elseif($b>$c){ 
    echo "Print b";
  }else{ 
    echo "not print";
  }
?>