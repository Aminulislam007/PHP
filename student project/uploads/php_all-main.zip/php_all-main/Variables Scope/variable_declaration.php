<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>variable-declaration</title>
</head>
<body>
    <h1>hello</h1>

<?php 

$color ="Hello";
$Color ="hi";
$COLOR ="bye";

echo $color ." ". $Color ." ". $COLOR;

?>




</body>
</html>