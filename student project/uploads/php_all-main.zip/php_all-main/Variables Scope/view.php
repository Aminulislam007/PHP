<?php 

echo $_GET['fname'];
echo "<br>";
echo $_GET['email'];

?>