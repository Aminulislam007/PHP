 <?php 
        function info(){ 
              $a = 12;
            echo $a;
        }
    info();
    
    ?>