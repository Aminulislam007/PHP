<?php 

$f=function(){ 
    echo "hi";
};
$f();

$v= function (){ 
    echo "hello bangladesh";
};
echo $v();

?>