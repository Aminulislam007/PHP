<h1>Function type(2)</h1>
<h4>User Define function</h4>
<h4>Buit-in(1000)</h4>
<p> 
    1.Numeric
    2.string
    3.Date time
</p>
<p> 
    1.unick name
    2.not start number 
    3.function keyword
    4.no speace
    5._function name like _name,_info
    6.function call
</p>
