<?php 
$a ="hi";
$c ="hello";
echo $a;

echo "<br>";
$b=print "$a . $c";
echo $b;




?>