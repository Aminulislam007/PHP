<?php 

$a=array("A","B","c");
$b=array("D","E","F");
$marge=array_merge($a,$b);
print_r($marge);

?>