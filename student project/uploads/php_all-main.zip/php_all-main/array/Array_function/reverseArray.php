<?php
$states = array("Washington","Vatican City","Dhaka","DC","Dhaka","DC");
	
		print_r(array_reverse($states));
		
//it can reverse the index number of an array

?>