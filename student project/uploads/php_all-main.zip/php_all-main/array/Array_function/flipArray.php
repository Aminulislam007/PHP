<?php

$state = array("Washington","Vatican City","Dhaka","DC");
	
	$state = array_flip($state);
	
		print_r($state);

//it can exchange the key & value

?>