<?php
$states = array("Washington","Vatican City","Dhaka","DC","Dhaka","DC");
	
	$stateFrequency = array_count_values($states);
	
		print_r($stateFrequency);
		
//how many times are situated elements in an array

?>