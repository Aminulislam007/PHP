<?php

$fruits = array("apple","orange","banana");

$fruit = next($fruits); //returns "orange"
$fruit = next($fruits); //returns "banana"

	echo $fruit;

//next index will show this function.

?>