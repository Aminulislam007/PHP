<?php
	$p=array("a","b","c","d");
	$q=array_shift($p);
		echo $q;
?>