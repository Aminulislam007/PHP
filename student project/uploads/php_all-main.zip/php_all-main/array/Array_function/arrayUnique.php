<?php
$states = array("Washington","Vatican City","Dhaka","DC","Dhaka","DC");
	$stateFrequency = array_unique($states);
	print_r($stateFrequency);

//it is removed the duplicate value of an array
?>