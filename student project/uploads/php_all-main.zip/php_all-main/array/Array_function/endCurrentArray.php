<?php

//current array
$fruits = array("apple","orange","banana");

$fruit = current($fruits); //returns "apple"

    echo $fruit."<br/>";
	
//end array

$b = array("apple","orange","banana");

$c = end($b); //returns "banana"

	echo $c;

?>