<?php 
$one=array(2,4,4);
$two=array(3,1,5);
$three=array(2,1,7);
$diff=array_diff($one,$two,$three);
print_r($diff);

?>