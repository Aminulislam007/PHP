<?php
/*$a = array ('a' => 'apple', 'b' => 'banana', 'c' => array ('x', 'y', 'z'));
print_r ($a);
?>*/

	$a=array("r");
		echo is_array($a);

?>

