<?php
	$a=array("a","b","c","d");
	$b=array_pop($a);
		echo $b;//a,b,c
?>