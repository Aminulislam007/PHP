<?php
$garden = array("cabbage","peepers","carrot","turnips");
	echo count($garden);
?>