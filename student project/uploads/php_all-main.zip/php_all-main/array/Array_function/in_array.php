<?php
	
	$a = array("Mac", "NT","NT", "Irix", "Linux");
		// $b=in_array("M",$a);
		$b=in_array("Mac",$a);
		echo $b;
?>