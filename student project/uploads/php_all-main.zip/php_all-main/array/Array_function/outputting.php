<?php
	$rowdra=array("sun","shine","sunny");
		foreach($rowdra as $rowdra){
			echo $rowdra;
			echo "<br/>";
		}
?>