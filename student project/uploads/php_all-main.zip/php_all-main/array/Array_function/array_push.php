<?php
 $a=array("a","b","c","d");
 $b=array_push($a,"e");
 	print_r($a);
	echo "<br/>";
	echo $b;



?>