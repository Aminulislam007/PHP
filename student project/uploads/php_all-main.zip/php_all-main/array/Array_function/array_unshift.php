<?php
	$a=array("dog","cat");
	$b=array_unshift($a,"cow","goat","elephant");
		echo $b;


?>