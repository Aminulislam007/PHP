
<?php 


$num = Array("A","B","C","D","E");
array_push($num,"X","y");
// var_dump($num);
foreach ($num as $value){ 
    echo $value;
}




?>
