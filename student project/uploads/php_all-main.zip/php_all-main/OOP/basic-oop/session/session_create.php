<?php  
session_start();
$_SESSION["carName"] = "BMW-sw";
echo "session is start set.";

?>