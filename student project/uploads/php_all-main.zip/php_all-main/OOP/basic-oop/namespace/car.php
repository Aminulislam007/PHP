<?php 
namespace Capp;
class Car { 
    public function info(){ 
        echo "This is Car.";
    }
}


?>