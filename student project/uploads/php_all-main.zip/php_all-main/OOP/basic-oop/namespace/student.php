<?php 
namespace Sapp;
class User{
    public $fname;
    public $lname;
    public function display () { 
        echo "This is loging page";
    }
}
?>