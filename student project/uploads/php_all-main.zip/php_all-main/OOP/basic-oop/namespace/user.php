<?php 
namespace Uapp;
class User{ 
    public $name;
    public $age;

    public function show () { 
        echo "this next page";
    }
}

?>
    