<?php 
echo $_SERVER['SERVER_NAME'];
echo"<br>";
echo $_SERVER['SCRIPT_NAME'];
echo"<br>";
echo $_SERVER['SERVER_ADDR'];
echo"<br>";
echo $_SERVER['SERVER_PORT'];

?>