<?php  
$x ="xd";

if(isset($x)){ 
echo "done";
}else{ 
    echo "not done";
}

// $y = null;
// if(isset($y)){ 
//  echo "variable 'Y'";
// }

?>