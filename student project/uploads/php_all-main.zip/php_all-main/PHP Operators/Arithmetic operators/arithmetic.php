<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Arithmetic</p>

<?php
$x = 10;  
$y = 6;

echo $x + $y;
?>

<?php
$x = 10;  
$y = 3;

echo $x ** $y;
?>  
</body>
</html>