<?php 


// increment
// pre

$x = 10;  
echo ++$x;//11 output new value x=x+1
echo "<br>";
echo $x;
 
echo "<br>";

echo "Post";
echo "<br>";
//post
$x = 10;  
echo $x++;//10 old value
echo "<br>";
echo $x;


//decrement


// $x = 10;  
// echo --$x;//9 output new value x=x-1
 

// //post
// $x = 10;  
// echo $x--;//10 old value
?>