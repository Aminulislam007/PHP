<?php
// no indentation

$f="this is now";
echo <<<END
         <h1>Hello $f</h1>
END;