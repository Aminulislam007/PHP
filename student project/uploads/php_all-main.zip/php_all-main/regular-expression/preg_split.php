<?php

print_r(preg_split("/[ ]/","This is a text element"));

?>