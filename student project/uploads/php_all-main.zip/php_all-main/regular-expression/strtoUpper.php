<?php

$a="rainbow";
$b=strtoupper($a);

	echo $b;


?>