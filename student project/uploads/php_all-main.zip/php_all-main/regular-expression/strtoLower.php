<?php

$a="TRThis is silent area.";
$b=strtolower($a);

	echo $b;


?>