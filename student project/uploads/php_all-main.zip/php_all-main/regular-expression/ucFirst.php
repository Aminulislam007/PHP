<?php

$a="there is a new river padma";

	echo ucfirst($a);

?>