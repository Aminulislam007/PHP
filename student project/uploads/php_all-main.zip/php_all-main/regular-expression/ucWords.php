<?php

$a="there is a new river padma";

	echo ucwords($a);

?>