<?php

$a = "admin@12354";
$b = "ADMIN@12345";


 $c = strcasecmp($a,$b);
 
 echo $c;"<br/>";
 //1
?>