<?php

$p="asdf123456";

$r=strcspn($p,"123456789");

	echo $r;


?>