<?php

$p="asdf123456";

$r=strspn("123456789",$p);

	echo $r;


?>