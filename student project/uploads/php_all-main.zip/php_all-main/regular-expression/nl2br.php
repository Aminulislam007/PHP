<?php

$a="these dolls,
that toys,
this car,
those gems.";

	echo nl2br($a);

?>