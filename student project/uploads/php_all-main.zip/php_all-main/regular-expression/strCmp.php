<?php

$a = "admin@12354";
$b = "admin@12354";


 $c = strcmp($a,$b);
 
 echo $c;"<br/>";
 
?>